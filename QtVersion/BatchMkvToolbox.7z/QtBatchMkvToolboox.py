from ui.mainwindow import Ui_MainWindow

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QFileDialog


def openFileNameDialog():
        fileName, _ = QFileDialog.getOpenFileName(None,"Select a file", "","Mkv files (*.mkv)")
        if fileName:
            print(fileName)
            ui.welcomeLabel.setText("Scanning tracks")
            ui.mkvParsingProgressbar.setVisible(True)
            ui.tabWidget.setVisible(True)

def openFolderDialog():
        fileName = QFileDialog.getExistingDirectory(None,"Test")
        if fileName:
            print(fileName)
            ui.welcomeLabel.setText("Scanning tracks")
            ui.mkvParsingProgressbar.setVisible(True)
            ui.tabWidget.setVisible(True)

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)

    ui.tabWidget.setVisible(False)
    ui.mkvParsingProgressbar.setVisible(False)

    ui.actionOpen_file.triggered.connect(lambda: openFileNameDialog())
    ui.actionOpen_folder.triggered.connect(lambda: openFolderDialog())
    ui.actionExit.triggered.connect(lambda: sys.exit(app.exec_()))

    MainWindow.show()
    sys.exit(app.exec_())